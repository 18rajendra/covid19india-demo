package org.records.cvoid19india.responses;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CovidRecord {
	private String agebracket;
	private String contractedfromwhichpatientsuspected;
	private String currentstatus;
	private String dateannounced;
	private String detectedcity;
	private String detecteddistrict;
	private String detectedstate;
	private String entryid;
	private String gender;
	private String nationality;
	private String notes;
	private String numcases;
	private String patientnumber;
	private String source1;
	private String source2;
	private String source3;
	private String statecode;
	private String statepatientnumber;
	private String statuschangedate;
	private String typeoftransmission;
}
