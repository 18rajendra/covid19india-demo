package org.records.cvoid19india.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.records.cvoid19india.responses.CovidRecord;
import org.records.cvoid19india.service.Covid19IndiaService;
import org.springframework.stereotype.Service;


@Service
public class Covid19IndiaServieImpl implements Covid19IndiaService {

	@Override
	public List<CovidRecord> getCovidDataByState(List<CovidRecord> rawData, String detectedstate) {
		List<CovidRecord> filteredData=rawData.stream()
				.filter(p->p.getDetectedstate().equals(detectedstate))
				.collect(Collectors.toList());
		return filteredData;
	}

}
