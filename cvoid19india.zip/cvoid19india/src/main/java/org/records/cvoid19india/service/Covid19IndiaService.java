package org.records.cvoid19india.service;

import java.util.List;

import org.records.cvoid19india.responses.CovidRecord;
import org.records.cvoid19india.responses.RawData;

public interface Covid19IndiaService {
	public List<CovidRecord> getCovidDataByState(List<CovidRecord> rawData, String detectedstate);
}
