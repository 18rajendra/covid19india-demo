package org.records.cvoid19india.responses;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResponseModal {
	private Integer statusCode;
	private Object responseData;
	private String message;
}
