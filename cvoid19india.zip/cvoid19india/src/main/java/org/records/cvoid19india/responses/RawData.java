package org.records.cvoid19india.responses;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RawData {
	List<CovidRecord> raw_data;
}
