package org.records.cvoid19india;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cvoid19indiaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Cvoid19indiaApplication.class, args);
	}

}
