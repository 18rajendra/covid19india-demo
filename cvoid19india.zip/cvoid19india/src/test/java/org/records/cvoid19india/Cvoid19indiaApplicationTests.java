package org.records.cvoid19india;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cvoid19indiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
